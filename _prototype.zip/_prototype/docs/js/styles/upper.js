var StrategyBasic;
(function (StrategyBasic) {
    class Upper {
        applyStyle(text) {
            text = text.toUpperCase();
            return text;
        }
    }
    StrategyBasic.Upper = Upper;
})(StrategyBasic || (StrategyBasic = {}));
