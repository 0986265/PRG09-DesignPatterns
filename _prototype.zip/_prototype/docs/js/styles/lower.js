var StrategyBasic;
(function (StrategyBasic) {
    class Lower {
        applyStyle(text) {
            text = text.toLowerCase();
            return text;
        }
    }
    StrategyBasic.Lower = Lower;
})(StrategyBasic || (StrategyBasic = {}));
