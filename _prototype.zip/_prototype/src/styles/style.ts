interface Style {
    applyStyle(text : string) : string
}