namespace StrategyBasic {

    export class Main {
    
        constructor() {
            let txt : Txt = new Txt("Hello World")
    
            txt.setStyle(new Upper())
        }
    
    }
    
}

window.addEventListener("load", () => new StrategyBasic.Main())